package Logica;

public class Cama {
	
	private String tipo;
	private int cantidadNinos;
	private int cantidadAdultos;
	
	
	//Constructor
	
	public Cama(String tipo, int cantidadNinos, int cantidadAdultos) {
		super();
		this.tipo = tipo;
		this.cantidadNinos = cantidadNinos;
		this.cantidadAdultos = cantidadAdultos;
	}


	public String getTipo() {
		return tipo;
	}
	
	public int cantidadNinos() {
		return cantidadNinos;
	}
	
	public int cantidadAdultos() {
		return cantidadAdultos;
	}
	
	
	

}
