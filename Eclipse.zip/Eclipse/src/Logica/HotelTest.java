package Logica;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.IOException;
import java.text.ParseException;

import static org.junit.jupiter.api.Assertions.*;

public class HotelTest {
    private Hotel hotel;

    @BeforeEach
    public void setUp() {
        hotel = new Hotel();
    }

    @Test
    public void cargarArchivos_shouldLoadData() {
        // Arrange
        // Ensure that the data files exist and contain the necessary data for testing

        // Act
        assertDoesNotThrow(() -> hotel.cargarArchivos());

        // Assert
        // Check that the data is loaded correctly
        // You can write assertions to verify that the data structures are populated as expected
        // For example:
        // assertEquals(expectedCamasCount, hotel.getCamas().size());
        // assertEquals(expectedHabitacionesCount, hotel.getInventario().size());
        // assertEquals(expectedUsuariosCount, hotel.getUsuarios().size());
        // ... and so on
    }

    @Test
    public void cargarArchivos_shouldThrowExceptionOnIOException() {
        // Arrange
        // Set up a scenario where an IOException is expected
        // For example, provide an invalid file path

        // Act & Assert
        assertThrows(IOException.class, () -> hotel.cargarArchivos());
    }

    @Test
    public void cargarArchivos_shouldThrowExceptionOnParseException() {
        // Arrange
        // Set up a scenario where a ParseException is expected
        // For example, provide invalid data in one of the data files

        // Act & Assert
        assertThrows(ParseException.class, () -> hotel.cargarArchivos());
    }
}