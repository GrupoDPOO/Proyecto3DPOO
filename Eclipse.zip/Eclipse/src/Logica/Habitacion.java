package Logica;
import java.util.ArrayList;

public class Habitacion {
	
	//Atributos
	
	private int identificador;
	private String ubicacion;
	private boolean balcon;
	private boolean vista;
	private boolean cocina;
	private ArrayList<Cama> camas;
	private String tipo;
	private int metrosCuadrados;
	private boolean aireAcondicionado;
	private boolean calefaccion;
	private boolean TV;
	private boolean cafetera;
	private boolean tapetesHipo;
	private boolean plancha;
	private boolean secador;
	private boolean voltajeAC;
	private boolean USBA;
	private boolean USBC;
	private boolean desayuno;
	
	
	//Constructor
	
	public Habitacion(int identificador, String ubicacion, boolean balcon,
			boolean vista, boolean cocina, ArrayList<Cama> camas, String tipo) {
		super();
		this.identificador = identificador;
		this.ubicacion = ubicacion;
		this.balcon = balcon;
		this.vista = vista;
		this.cocina = cocina;
		this.camas = camas;
		this.tipo=tipo;
		

	}
	
	

	public Habitacion(int identificador, String ubicacion, boolean balcon, boolean vista, boolean cocina,
			ArrayList<Cama> camas, String tipo, int metrosCuadrados, boolean aireAcondicionado, boolean calefaccion,
			boolean tV, boolean cafetera, boolean tapetesHipo, boolean plancha, boolean secador, boolean voltajeAC,
			boolean uSBA, boolean uSBC, boolean desayuno) {
		super();
		this.identificador = identificador;
		this.ubicacion = ubicacion;
		this.balcon = balcon;
		this.vista = vista;
		this.cocina = cocina;
		this.camas = camas;
		this.tipo = tipo;
		this.metrosCuadrados = metrosCuadrados;
		this.aireAcondicionado = aireAcondicionado;
		this.calefaccion = calefaccion;
		TV = tV;
		this.cafetera = cafetera;
		this.tapetesHipo = tapetesHipo;
		this.plancha = plancha;
		this.secador = secador;
		this.voltajeAC = voltajeAC;
		USBA = uSBA;
		USBC = uSBC;
		this.desayuno = desayuno;
	}



	public int getIdentificador() {
		return identificador;
	}

	

    public String getUbicacion() {
        return ubicacion;
    }

    
    public boolean isBalcon() {
        return balcon;
    }

  
    public boolean isVista() {
        return vista;
    }

   

    public boolean isCocina() {
        return cocina;
    }

  

    public ArrayList<Cama> getCamas() {
        return camas;
    }

  

    public String getTipo() {
        return tipo;
    }

    

	@Override
	public String toString() {
		
		return identificador + ";" + ubicacion + ";" + balcon
				+ ";" + vista + ";" + cocina + ";" + "mediana" + ";" + tipo;
	}
	
	public int capacidadNinos() {
		
		
		return 3;
	}
	
	public int capacidadAdultos() {
		
		
		return 2;
	}
	
	public int capacidad() {
		int total=0;
		int capN = this.capacidadNinos();
		int capA = this.capacidadAdultos();
		total= capN + capA;
		
		return total;
	}



	public int getMetrosCuadrados() {
		return metrosCuadrados;
	}



	public boolean isAireAcondicionado() {
		return aireAcondicionado;
	}



	public boolean isCalefaccion() {
		return calefaccion;
	}



	public boolean isTV() {
		return TV;
	}



	public boolean isCafetera() {
		return cafetera;
	}



	public boolean isTapetesHipo() {
		return tapetesHipo;
	}



	public boolean isPlancha() {
		return plancha;
	}



	public boolean isSecador() {
		return secador;
	}



	public boolean isUSBA() {
		return USBA;
	}



	public boolean isUSBC() {
		return USBC;
	}



	public boolean isDesayuno() {
		return desayuno;
	}



	public void setVista(boolean vista) {
		this.vista = vista;
	}



	public boolean isVoltajeAC() {
		return voltajeAC;
	}
	
	
	
	
	
	
	
	
	

}
