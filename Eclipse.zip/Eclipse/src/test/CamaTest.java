package test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Logica.Cama;

public class CamaTest {

    @Test
    public void testGetTipo() {
        Cama cama = new Cama("Individual", 0, 1);
        Assertions.assertEquals("Individual", cama.getTipo());
    }

    @Test
    public void testCantidadNinos() {
        Cama cama = new Cama("Matrimonial", 2, 1);
        Assertions.assertEquals(2, cama.cantidadNinos());
    }

    @Test
    public void testCantidadAdultos() {
        Cama cama = new Cama("Queen", 0, 2);
        Assertions.assertEquals(2, cama.cantidadAdultos());
    }
}
