package test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Logica.Servicio;

public class ServicioTest {

    @Test
    public void testGetProducto() {
        Servicio servicio = new Servicio("001", "Masaje", "10:00", "12:00", 50.0);
        Assertions.assertEquals("Masaje", servicio.getProducto());
    }

    @Test
    public void testGetHoraInicial() {
        Servicio servicio = new Servicio("001", "Masaje", "10:00", "12:00", 50.0);
        Assertions.assertEquals("10:00", servicio.getHoraInicial());
    }

    @Test
    public void testGetHoraFinal() {
        Servicio servicio = new Servicio("001", "Masaje", "10:00", "12:00", 50.0);
        Assertions.assertEquals("12:00", servicio.getHoraFinal());
    }

    @Test
    public void testGetPrecio() {
        Servicio servicio = new Servicio("001", "Masaje", "10:00", "12:00", 50.0);
        Assertions.assertEquals(50.0, servicio.getPrecio());
    }
    
    @Test
    public void testGetCodigo() {
        Servicio servicio = new Servicio("001", "Masaje", "10:00", "12:00", 50.0);
        Assertions.assertEquals("001", servicio.getCodigo());
    }
}
