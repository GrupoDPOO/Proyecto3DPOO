package test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Logica.Usuario;

public class UsuarioTest {

    @Test
    public void testGetters() {
        // Crear un objeto de prueba
        String rol = "Administrador";
        String nombre = "John Doe";
        String documento = "123456789";
        String correo = "johndoe@example.com";
        String telefono = "1234567890";
        String user = "johndoe";
        String clave = "password";

        Usuario usuario = new Usuario(rol, nombre, documento, correo, telefono, user, clave);

        // Verificar los valores obtenidos a través de los getters
        Assertions.assertEquals(rol, usuario.getRol());
        Assertions.assertEquals(nombre, usuario.getNombre());
        Assertions.assertEquals(user, usuario.getUser());
        Assertions.assertEquals(clave, usuario.getClave());
    }
}
