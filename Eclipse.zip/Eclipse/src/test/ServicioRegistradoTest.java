package test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Logica.ServicioRegistrado;

public class ServicioRegistradoTest {

    @Test
    public void testGetIdReserva() {
        ServicioRegistrado servicioRegistrado = new ServicioRegistrado(1, "Lavandería", 20.0);
        Assertions.assertEquals(1, servicioRegistrado.getIdReserva());
    }

    @Test
    public void testGetServicio() {
        ServicioRegistrado servicioRegistrado = new ServicioRegistrado(1, "Lavandería", 20.0);
        Assertions.assertEquals("Lavandería", servicioRegistrado.getServicio());
    }

    @Test
    public void testGetPrecio() {
        ServicioRegistrado servicioRegistrado = new ServicioRegistrado(1, "Lavandería", 20.0);
        Assertions.assertEquals(20.0, servicioRegistrado.getPrecio());
    }
}