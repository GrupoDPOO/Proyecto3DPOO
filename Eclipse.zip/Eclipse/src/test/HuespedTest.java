package test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Logica.Huesped;

public class HuespedTest {

    @Test
    public void testGetNombre() {
        Huesped huesped = new Huesped(1, 1, "Juan Perez", "12345678", "juan@example.com", "123456789", 1);
        Assertions.assertEquals("Juan Perez", huesped.getNombre());
    }

    @Test
    public void testGetId() {
        Huesped huesped = new Huesped(1, 1, "Juan Perez", "12345678", "juan@example.com", "123456789", 1);
        Assertions.assertEquals(1, huesped.getId());
    }

    @Test
    public void testGetIdReserva() {
        Huesped huesped = new Huesped(1, 1, "Juan Perez", "12345678", "juan@example.com", "123456789", 1);
        Assertions.assertEquals(1, huesped.getIdReserva());
    }

    @Test
    public void testGetDocumento() {
        Huesped huesped = new Huesped(1, 1, "Juan Perez", "12345678", "juan@example.com", "123456789", 1);
        Assertions.assertEquals("12345678", huesped.getDocumento());
    }

    @Test
    public void testGetCorreo() {
        Huesped huesped = new Huesped(1, 1, "Juan Perez", "12345678", "juan@example.com", "123456789", 1);
        Assertions.assertEquals("juan@example.com", huesped.getCorreo());
    }

    @Test
    public void testGetTelefono() {
        Huesped huesped = new Huesped(1, 1, "Juan Perez", "12345678", "juan@example.com", "123456789", 1);
        Assertions.assertEquals("123456789", huesped.getTelefono());
    }

    @Test
    public void testGetCantidadPersonas() {
        Huesped huesped = new Huesped(1, 1, "Juan Perez", "12345678", "juan@example.com", "123456789", 1);
        Assertions.assertEquals(1, huesped.getCantidadPersonas());
    }
}