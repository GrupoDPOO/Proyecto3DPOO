package vistaHuespedes;

import javax.swing.JPanel;

import Vista.DisponibilidadPorFecha;

import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;

public class panelBotones extends JPanel{

	JPanel disponibilidad;
	private ventanaPrincipal ventana; 
	
	public panelBotones() {
		setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JLabel lblNewLabel = new JLabel("Bienvenido");
		add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Consultar disp");
		add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Reservar habitación");
		add(btnNewButton_1);
		
		btnNewButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			disponibilidad = new DisponibilidadPorFecha();
			
	}

});
}
	public JPanel getPanel()
	{
		return disponibilidad;
	}
}
