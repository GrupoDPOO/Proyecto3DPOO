package vistaHuespedes;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Logica.Habitacion;
import Logica.Hotel;
import Logica.Usuario;
import Vista.DisponibilidadPorFecha;
import Vista.MenuEmpleado;
import Vista.RealizarReserva;
import Vista.VentanaPrincipal;

import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JDesktopPane;
import javax.swing.JSplitPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import java.awt.FlowLayout;

import javax.swing.SpringLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.CardLayout;
import java.awt.GridLayout;
import java.awt.Color;

public class ventanaPrincipal extends JFrame {
	
	private JPanel panel_1;
	private JPanel panel_2;
	private JPanel contentPane;
	private panelBotones panelBotones = new panelBotones();
	private JLabel lblBienvenido = new JLabel("               Bienvenido");
	private JButton btnDisponibilidad = new JButton("Disponibilidad por fechas");
	private JButton btnReservar = new JButton("Reservar habitación");
	private JLabel label;
	private JLabel label_1;
	private DisponibilidadPorFecha disponibilidad;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ventanaPrincipal frame = new ventanaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ventanaPrincipal() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 731, 699);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		panel_1 = new JPanel();
		panel_1.setVisible(true);
		contentPane.add(panel_1, BorderLayout.WEST);
		panel_1.setLayout(new GridLayout(0, 1, 0, 0));
		lblBienvenido.setForeground(new Color(128, 0, 128));
		lblBienvenido.setBackground(new Color(0, 255, 255));
		panel_1.add(lblBienvenido);
		btnDisponibilidad.setForeground(new Color(255, 255, 255));
		btnDisponibilidad.setBackground(new Color(128, 0, 128));
		panel_1.add(btnDisponibilidad);
		btnDisponibilidad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    disponibilidad = new DisponibilidadPorFecha();
				disponibilidad.setSize(403,300);
				panel_2.removeAll();
				panel_2.add(disponibilidad);
				disponibilidad.setLocation(0,0);
				panel_2.revalidate();
				panel_2.repaint();
				
			}
		});
		btnReservar.setForeground(new Color(255, 255, 255));
		btnReservar.setBackground(new Color(128, 0, 128));
		btnReservar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				RealizarReserva reserva = new RealizarReserva();
				panel_2.removeAll();
				panel_2.add(reserva);
				reserva.setLocation(0,0);
				panel_2.revalidate();
				panel_2.repaint();
				
			}
		});
		panel_1.add(btnReservar);
		
		label = new JLabel("");
		label.setBackground(new Color(0, 255, 255));
		panel_1.add(label);
		
		label_1 = new JLabel("");
		label_1.setBackground(new Color(0, 255, 255));
		panel_1.add(label_1);
		
		panel_2 = new JPanel();
		contentPane.add(panel_2, BorderLayout.CENTER);
		panel_2.setLayout(new BorderLayout(0, 0));
		
	}
		
	}