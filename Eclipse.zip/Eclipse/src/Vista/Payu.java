package Vista;

import javax.swing.JOptionPane;

public class Payu implements PasarelaPago {
    public boolean realizarPago(double monto, String numeroCuenta) {
       
    	JOptionPane.showMessageDialog(null,"Pago realizado con éxito a través de PayU");
        return true;
    }
}