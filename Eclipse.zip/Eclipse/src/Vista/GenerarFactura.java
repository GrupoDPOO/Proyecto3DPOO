package Vista;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import Logica.Hotel;

import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.ParseException;
import java.awt.event.ActionEvent;

public class GenerarFactura extends JPanel {
    private JTextField txtDocumento;

    public GenerarFactura() {
        setLayout(null);

        JLabel lblNewLabel = new JLabel("Documento Huesped:");
        lblNewLabel.setBounds(71, 52, 103, 31);
        add(lblNewLabel);

        txtDocumento = new JTextField();
        txtDocumento.setBounds(189, 57, 143, 26);
        add(txtDocumento);
        txtDocumento.setColumns(10);

        JButton btnNewButton = new JButton("Generar Factura");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                Hotel hotel = new Hotel();
                try {
                    hotel.generarFactura(txtDocumento.getText());
                    int opcion = JOptionPane.showOptionDialog(null, "Factura guardada en el sistema. ¿Desea realizar un pago?",
                            "Confirmación de Pago", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null,
                            new Object[]{"Pagar", "No Pagar"}, "Pagar");

                    if (opcion == JOptionPane.YES_OPTION) {
                        // Lógica para realizar el pago
                        // ...
                         
                    	JFrame frame = new JFrame();
                    	JPanel pasarelas = new PasarelasPanel();
                    	JLabel label = new JLabel("Seleccione el método de pago:");
                    	frame.add(label);
                    	frame.add(pasarelas);
                    	frame.setSize(500,500);
                    	frame.setLocationRelativeTo(null);
                    	frame.setVisible(true);
                    	
                        
                    } else {
                        // Lógica para no realizar el pago
                        // ...
                        JOptionPane.showMessageDialog(null, "Pago no realizado.");
                    }
                } catch (IOException | ParseException e1) {
                    e1.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error al generar la factura");
                }
            }
        });
        btnNewButton.setBounds(154, 142, 134, 50);
        add(btnNewButton);
    }
}

