package Vista;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.JPanel;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.JPanel;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.JPanel;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class GraficaConteoMetodosPago {
    public static JPanel createChartPanel() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        // Leer el archivo serviciosRegistrados.txt y contar las ocurrencias de cada método de pago
        try (BufferedReader br = new BufferedReader(new FileReader("data/PagosTarjeta.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(";");
                if (data.length >= 1) {
                    String metodoPago = data[0].trim();
                    if (dataset.getColumnKeys().contains(metodoPago)) {
                        dataset.incrementValue(1, "Conteo", metodoPago);
                    } else {
                        dataset.addValue(1, "Conteo", metodoPago);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Crear la gráfica de barras
        JFreeChart chart = ChartFactory.createBarChart(
                "Conteo de Métodos de Pago",
                "Método de Pago",
                "Cantidad",
                dataset
        );

        // Crear el panel del gráfico y retornarlo
        ChartPanel chartPanel = new ChartPanel(chart);
        return chartPanel;
    }
}






