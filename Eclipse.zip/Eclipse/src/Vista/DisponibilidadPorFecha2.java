package Vista;

import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import Logica.Habitacion;
import Logica.Hotel;

import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class DisponibilidadPorFecha2 {
	private JTextField txtInicio;
	private JTextField txtFinal;
	private JTable tablaReservas;
	private DefaultTableModel model;
	private ArrayList<Habitacion> habitaciones;

	
			public ArrayList<Habitacion> habsFecha(String entrada,String salida) throws ParseException, IOException {
				
				Hotel hotel = new Hotel();
				
			    return habitaciones = hotel.habitacionesPorFecha(entrada,salida);
				
			}

}