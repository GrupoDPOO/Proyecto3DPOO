package Vista;

public interface PasarelaPago {
    boolean realizarPago(double monto, String numeroCuenta);
}