package Vista;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.SwingUtilities;

public class DatosPagoPanel extends JPanel {
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;

    /**
     * Create the panel.
     */
    public DatosPagoPanel(String pasarela) {
        setLayout(null);

        JLabel lblNombre = new JLabel("Nombre del dueño de la tarjeta:");
        lblNombre.setBounds(32, 72, 161, 14);
        add(lblNombre);

        JLabel lblMonto = new JLabel("Monto a cancelar:");
        lblMonto.setBounds(32, 121, 89, 14);
        add(lblMonto);

        JLabel lblNumTarjeta = new JLabel("Número de cuenta:");
        lblNumTarjeta.setBounds(32, 174, 104, 14);
        add(lblNumTarjeta);

        textField = new JTextField();
        textField.setBounds(124, 118, 161, 20);
        add(textField);
        textField.setColumns(10);

        textField_1 = new JTextField();
        textField_1.setBounds(189, 69, 140, 20);
        add(textField_1);
        textField_1.setColumns(10);

        textField_2 = new JTextField();
        textField_2.setBounds(137, 171, 148, 20);
        add(textField_2);
        textField_2.setColumns(10);

        JButton btnPagar = new JButton("PAGAR");
        btnPagar.setBounds(168, 230, 89, 23);
        add(btnPagar);
        btnPagar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nombre = textField_1.getText();
                String monto = textField.getText();
                String numTarjeta = textField_2.getText();
                if (nombre.isEmpty() || monto.isEmpty() || numTarjeta.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Todos los campos deben estar completos");
                    textField.setText("");
                    textField_1.setText("");
                    textField_2.setText("");
                } else {
                    try (BufferedWriter writer = new BufferedWriter(new FileWriter("./data/PagosTarjeta.txt", true))) {
                        writer.write(monto);
                        writer.write(";");
                        writer.write(numTarjeta);
                        writer.write(";");
                        writer.write(nombre);
                        writer.newLine();
                        String className = pasarela;
                        String packageName = "Vista";
                        String qualifiedClassName = packageName + "." + className;

                        // Acceder a la clase correspondiente
                        Class<?> paymentClass = Class.forName(qualifiedClassName);
                        Object paymentInstance = paymentClass.newInstance();
                        if (paymentInstance instanceof PasarelaPago) {
                            PasarelaPago paymentGateway = (PasarelaPago) paymentInstance;
                            paymentGateway.realizarPago(Double.parseDouble(monto), numTarjeta);
                 
                        }

                    } catch (IOException | ClassNotFoundException | InstantiationException | IllegalAccessException ex) {
                        ex.printStackTrace();
                    }

                    // Cerrar el frame actual
                    SwingUtilities.getWindowAncestor(DatosPagoPanel.this).dispose();
                }
            }
        });
    }

}


